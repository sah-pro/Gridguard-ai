"""
GridGuard - FastAPI Backend
Run: cd GridGuard/backend && python -m uvicorn main:app --port 8000
"""
from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
from pydantic import BaseModel
from typing import List, Optional
import pandas as pd
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ROOT_DIR = os.path.dirname(BASE_DIR)
DATA_DIR = os.path.join(ROOT_DIR, "data")

_risk_summary: Optional[pd.DataFrame] = None
_predictions:  Optional[pd.DataFrame] = None

def load_data():
    global _risk_summary, _predictions
    risk_path = os.path.join(DATA_DIR, "risk_summary.csv")
    pred_path = os.path.join(DATA_DIR, "predictions.csv")
    if os.path.exists(risk_path):
        _risk_summary = pd.read_csv(risk_path)
        print(f"✅ Loaded risk_summary: {len(_risk_summary)} meters")
    else:
        print(f"⚠️  risk_summary.csv not found at {risk_path}")
    if os.path.exists(pred_path):
        _predictions = pd.read_csv(pred_path)
        _predictions["timestamp"] = pd.to_datetime(_predictions["timestamp"])
        print(f"✅ Loaded predictions: {len(_predictions)} rows")
    else:
        print(f"⚠️  predictions.csv not found at {pred_path}")

@asynccontextmanager
async def lifespan(app: FastAPI):
    load_data()
    print("✅ GridGuard API started at http://localhost:8000")
    print("📖 API Docs at http://localhost:8000/docs")
    yield

app = FastAPI(title="GridGuard API", description="AI-powered smart meter anomaly detection for BESCOM", version="1.0.0", lifespan=lifespan)

app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

ZONE_COORDS = {
    "Zone_A": (12.9716, 77.5946), "Zone_B": (13.0068, 77.5855),
    "Zone_C": (12.9352, 77.6244), "Zone_D": (12.9279, 77.6271),
    "Zone_E": (13.0456, 77.6205), "Zone_F": (12.8782, 77.6408),
    "Zone_G": (12.9698, 77.7500), "Zone_H": (13.0550, 77.5500),
}

class MeterRisk(BaseModel):
    meter_id: str; zone: str; feeder: str; meter_type: str
    final_risk_score: float; dominant_loss_category: str
    anomaly_count: int; anomaly_rate: float

class AnomalyAlert(BaseModel):
    meter_id: str; timestamp: str; consumption_kwh: float
    risk_score: float; predicted_loss_category: str; zone: str; feeder: str

class ZoneSummary(BaseModel):
    zone: str; total_meters: int; anomalous_meters: int; avg_risk_score: float
    total_anomalies: int; technical_losses: int; non_technical_losses: int; lat: float; lng: float

class DashboardStats(BaseModel):
    total_meters: int; anomalous_meters: int; high_risk_meters: int
    technical_losses: int; non_technical_losses: int; avg_risk_score: float

@app.get("/", tags=["Health"])
def root():
    return {"status": "GridGuard API is running", "version": "1.0.0", "docs": "/docs"}

@app.get("/dashboard/stats", response_model=DashboardStats, tags=["Dashboard"])
def get_dashboard_stats():
    if _risk_summary is None:
        raise HTTPException(status_code=503, detail="Run detector.py first to generate risk_summary.csv")
    df = _risk_summary
    return DashboardStats(
        total_meters=int(len(df)),
        anomalous_meters=int((df["anomaly_count"] > 0).sum()),
        high_risk_meters=int((df["final_risk_score"] >= 60).sum()),
        technical_losses=int((df["dominant_loss_category"] == "technical").sum()),
        non_technical_losses=int((df["dominant_loss_category"] == "non_technical").sum()),
        avg_risk_score=float(round(df["final_risk_score"].mean(), 2)),
    )

@app.get("/meters/high-risk", response_model=List[MeterRisk], tags=["Meters"])
def get_high_risk_meters(limit: int = Query(50, le=200), zone: Optional[str] = None, loss_type: Optional[str] = None, min_risk: float = 0):
    if _risk_summary is None:
        raise HTTPException(status_code=503, detail="Data not loaded")
    df = _risk_summary.copy()
    if zone: df = df[df["zone"] == zone]
    if loss_type: df = df[df["dominant_loss_category"] == loss_type]
    df = df[df["final_risk_score"] >= min_risk].sort_values("final_risk_score", ascending=False).head(limit)
    return [MeterRisk(meter_id=str(r.meter_id), zone=str(r.zone), feeder=str(r.feeder), meter_type=str(r.meter_type), final_risk_score=float(r.final_risk_score), dominant_loss_category=str(r.dominant_loss_category), anomaly_count=int(r.anomaly_count), anomaly_rate=float(round(r.anomaly_rate, 4))) for r in df.itertuples()]

@app.get("/alerts/recent", response_model=List[AnomalyAlert], tags=["Alerts"])
def get_recent_alerts(limit: int = Query(100, le=500)):
    if _predictions is None:
        raise HTTPException(status_code=503, detail="Data not loaded")
    df = _predictions[_predictions["predicted_anomaly"] == True].copy()
    df = df.sort_values("timestamp", ascending=False).head(limit)
    return [AnomalyAlert(meter_id=str(r.meter_id), timestamp=str(r.timestamp), consumption_kwh=float(round(r.consumption_kwh, 4)), risk_score=float(round(r.risk_score, 2)), predicted_loss_category=str(r.predicted_loss_category), zone=str(r.zone), feeder=str(r.feeder)) for r in df.itertuples()]

@app.get("/zones/summary", response_model=List[ZoneSummary], tags=["Zones"])
def get_zone_summary():
    if _risk_summary is None:
        raise HTTPException(status_code=503, detail="Data not loaded")
    zones = []
    for zone, group in _risk_summary.groupby("zone"):
        lat, lng = ZONE_COORDS.get(zone, (12.9716, 77.5946))
        zones.append(ZoneSummary(zone=str(zone), total_meters=int(len(group)), anomalous_meters=int((group["anomaly_count"] > 0).sum()), avg_risk_score=float(round(group["final_risk_score"].mean(), 2)), total_anomalies=int(group["anomaly_count"].sum()), technical_losses=int((group["dominant_loss_category"] == "technical").sum()), non_technical_losses=int((group["dominant_loss_category"] == "non_technical").sum()), lat=lat, lng=lng))
    return sorted(zones, key=lambda z: z.avg_risk_score, reverse=True)

@app.get("/meter/{meter_id}/history", tags=["Meters"])
def get_meter_history(meter_id: str, last_n_readings: int = 96):
    if _predictions is None:
        raise HTTPException(status_code=503, detail="Data not loaded")
    df = _predictions[_predictions["meter_id"] == meter_id]
    if df.empty:
        raise HTTPException(status_code=404, detail=f"Meter {meter_id} not found")
    df = df.sort_values("timestamp").tail(last_n_readings)
    return {"meter_id": meter_id, "zone": df["zone"].iloc[0], "feeder": df["feeder"].iloc[0], "readings": df[["timestamp","consumption_kwh","risk_score","predicted_anomaly","predicted_loss_category"]].assign(timestamp=lambda x: x["timestamp"].astype(str)).to_dict(orient="records")}

@app.post("/reload-data", tags=["Admin"])
def reload_data():
    load_data()
    return {"status": "Data reloaded"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000)