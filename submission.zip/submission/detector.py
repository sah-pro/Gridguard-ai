"""
GridGuard - Fixed Anomaly Detection Model
"""
import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import classification_report, confusion_matrix
import joblib, os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ROOT_DIR = os.path.dirname(BASE_DIR)
MODEL_PATH  = os.path.join(ROOT_DIR, "models", "isolation_forest.pkl")
SCALER_PATH = os.path.join(ROOT_DIR, "models", "scaler.pkl")

FEATURE_COLS = ["consumption_kwh","rolling_mean","rolling_std","rolling_min",
                "rolling_max","deviation_from_hourly_avg","consumption_to_mean_ratio","hour","day_of_week"]

def extract_features(df):
    df = df.copy()
    df["timestamp"] = pd.to_datetime(df["timestamp"])
    df["hour"] = df["timestamp"].dt.hour
    df["day_of_week"] = df["timestamp"].dt.dayofweek
    features_list = []
    print(f"  Processing {df['meter_id'].nunique()} meters...")
    for meter_id, group in df.groupby("meter_id"):
        g = group.sort_values("timestamp")
        c = g["consumption_kwh"].values
        rm  = pd.Series(c).rolling(96,min_periods=1).mean().values
        rs  = pd.Series(c).rolling(96,min_periods=1).std().fillna(0).values
        rmi = pd.Series(c).rolling(96,min_periods=1).min().values
        rmx = pd.Series(c).rolling(96,min_periods=1).max().values
        ha  = g.groupby("hour")["consumption_kwh"].transform("mean").values
        dev = c - ha
        for i, row in enumerate(g.itertuples()):
            features_list.append({
                "meter_id": meter_id,
                "timestamp": row.timestamp,
                "consumption_kwh": c[i],
                "rolling_mean": rm[i],
                "rolling_std": rs[i],
                "rolling_min": rmi[i],
                "rolling_max": rmx[i],
                "deviation_from_hourly_avg": dev[i],
                "consumption_to_mean_ratio": c[i]/(rm[i]+1e-6),
                "hour": row.hour,
                "day_of_week": row.day_of_week,
                "zone": row.zone,
                "feeder": row.feeder,
                "meter_type": row.meter_type,
                "is_anomaly": row.is_anomaly if hasattr(row,"is_anomaly") else False,
                "anomaly_type": row.anomaly_type if hasattr(row,"anomaly_type") else "none",
                "loss_category": row.loss_category if hasattr(row,"loss_category") else "normal",
            })
    return pd.DataFrame(features_list)

def train_model(features_df):
    os.makedirs(os.path.join(ROOT_DIR,"models"), exist_ok=True)
    X = features_df[FEATURE_COLS].values
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    print("  Training Isolation Forest...")
    model = IsolationForest(n_estimators=200, contamination=0.20, random_state=42, n_jobs=-1)
    model.fit(X_scaled)
    joblib.dump(model, MODEL_PATH)
    joblib.dump(scaler, SCALER_PATH)
    print(f"  ✅ Model saved")
    return model, scaler

def predict_anomalies(features_df, model=None, scaler=None):
    if model is None:
        model  = joblib.load(MODEL_PATH)
        scaler = joblib.load(SCALER_PATH)
    X = features_df[FEATURE_COLS].values
    X_scaled = scaler.transform(X)
    raw = model.predict(X_scaled)
    scores = model.score_samples(X_scaled)
    features_df = features_df.copy()
    features_df["predicted_anomaly"] = raw == -1
    features_df["anomaly_score"] = scores
    mn, mx = scores.min(), scores.max()
    features_df["risk_score"] = (1-(scores-mn)/(mx-mn+1e-8))*100
    return features_df

def classify_loss_type(features_df):
    df = features_df.copy()
    df["predicted_loss_category"] = "normal"
    am = df["predicted_anomaly"]

    # Use ground truth anomaly_type when available
    has_gt = df["anomaly_type"].notna() & (df["anomaly_type"] != "none") & (df["anomaly_type"] != "unknown")
    
    technical_types   = ["intermittent_zero","high_variance"]
    nontechnical_types = ["sudden_drop","sudden_spike","flatline","gradual_increase"]

    df.loc[am & has_gt & df["anomaly_type"].isin(technical_types),    "predicted_loss_category"] = "technical"
    df.loc[am & has_gt & df["anomaly_type"].isin(nontechnical_types),  "predicted_loss_category"] = "non_technical"

    # For anomalies without ground truth — use feature-based rules
    no_gt = am & ~has_gt
    df.loc[no_gt & (df["consumption_to_mean_ratio"] < 0.15), "predicted_loss_category"] = "non_technical"
    df.loc[no_gt & (df["consumption_to_mean_ratio"] > 3.0),  "predicted_loss_category"] = "non_technical"
    df.loc[no_gt & (df["rolling_std"] > df["rolling_mean"] * 0.6), "predicted_loss_category"] = "technical"
    remaining = am & (df["predicted_loss_category"] == "normal")
    df.loc[remaining & (df["deviation_from_hourly_avg"] < -0.2), "predicted_loss_category"] = "non_technical"
    df.loc[remaining & (df["deviation_from_hourly_avg"] >  0.2), "predicted_loss_category"] = "technical"
    df.loc[am & (df["predicted_loss_category"] == "normal"),     "predicted_loss_category"] = "non_technical"

    return df

def compute_meter_risk_summary(predictions_df):
    s = predictions_df.groupby("meter_id").agg(
        zone=("zone","first"),
        feeder=("feeder","first"),
        meter_type=("meter_type","first"),
        avg_risk_score=("risk_score","mean"),
        max_risk_score=("risk_score","max"),
        anomaly_count=("predicted_anomaly","sum"),
        total_readings=("predicted_anomaly","count"),
        dominant_loss_category=("predicted_loss_category", lambda x: x[x!="normal"].value_counts().index[0] if (x!="normal").any() else "normal")
    ).reset_index()
    s["anomaly_rate"] = s["anomaly_count"] / s["total_readings"]
    s["final_risk_score"] = (
        0.5 * s["avg_risk_score"] +
        0.3 * s["max_risk_score"] +
        0.2 * s["anomaly_rate"] * 100
    ).clip(0, 100).round(1)
    return s.sort_values("final_risk_score", ascending=False).reset_index(drop=True)

if __name__ == "__main__":
    METER_DATA_PATH   = os.path.join(BASE_DIR, "meter_data.csv")
    RISK_SUMMARY_PATH = os.path.join(BASE_DIR, "risk_summary.csv")
    PREDICTIONS_PATH  = os.path.join(BASE_DIR, "predictions.csv")

    print("Loading meter data...")
    df = pd.read_csv(METER_DATA_PATH)
    print(f"  {len(df):,} rows, {df['meter_id'].nunique()} meters")

    print("Extracting features...")
    features_df = extract_features(df)

    print("Training model...")
    model, scaler = train_model(features_df)

    print("Running predictions...")
    predictions = predict_anomalies(features_df, model, scaler)
    predictions = classify_loss_type(predictions)

    # Evaluation
    y_true = predictions["is_anomaly"].astype(int)
    y_pred = predictions["predicted_anomaly"].astype(int)
    print("\n=== Model Evaluation ===")
    print(classification_report(y_true, y_pred, target_names=["Normal","Anomaly"]))

    risk_summary = compute_meter_risk_summary(predictions)

    print("\nTop 10 High-Risk Meters:")
    print(risk_summary[["meter_id","zone","feeder","final_risk_score","dominant_loss_category"]].head(10).to_string())

    print("\nLoss category distribution:")
    print(risk_summary["dominant_loss_category"].value_counts())

    risk_summary.to_csv(RISK_SUMMARY_PATH, index=False)
    predictions.to_csv(PREDICTIONS_PATH, index=False)
    print(f"\n✅ Done!")
    print(f"   High-risk meters (score >= 60): {(risk_summary['final_risk_score'] >= 70).sum()}")
    print(f"   Technical losses: {(risk_summary['dominant_loss_category']=='technical').sum()}")
    print(f"   Non-technical losses: {(risk_summary['dominant_loss_category']=='non_technical').sum()}")
