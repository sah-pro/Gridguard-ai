import { useState, useEffect, useCallback } from "react";

const API = "https://gridguard-backend.onrender.com";

const riskColor = (s) => s >= 70 ? "#ef4444" : s >= 40 ? "#f59e0b" : "#22c55e";
const riskLabel = (s) => s >= 70 ? "HIGH" : s >= 40 ? "MEDIUM" : "LOW";

// ── Mini SVG line chart for meter history ─────────────────────────────────────
function SparkChart({ readings }) {
  if (!readings || readings.length === 0) return null;
  const W = 560, H = 180, PAD = 36;
  const vals = readings.map(r => r.consumption_kwh);
  const minV = Math.min(...vals), maxV = Math.max(...vals);
  const range = maxV - minV || 1;
  const pts = readings.map((r, i) => {
    const x = PAD + (i / (readings.length - 1)) * (W - PAD * 2);
    const y = PAD + (1 - (r.consumption_kwh - minV) / range) * (H - PAD * 2);
    return { x, y, ...r };
  });
  const line = pts.map((p, i) => `${i === 0 ? "M" : "L"}${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(" ");
  const area = line + ` L${pts[pts.length-1].x},${H-PAD} L${pts[0].x},${H-PAD} Z`;
  const anomalies = pts.filter(p => p.predicted_anomaly);
  // x-axis labels (every 10 readings)
  const xLabels = pts.filter((_, i) => i % Math.max(1, Math.floor(readings.length / 6)) === 0);

  return (
    <svg viewBox={`0 0 ${W} ${H}`} style={{ width: "100%", height: 180, display: "block" }}>
      {/* Grid lines */}
      {[0, 0.25, 0.5, 0.75, 1].map(t => {
        const y = PAD + t * (H - PAD * 2);
        const v = (maxV - t * range).toFixed(2);
        return (
          <g key={t}>
            <line x1={PAD} y1={y} x2={W - PAD} y2={y} stroke="#334155" strokeWidth="0.5" strokeDasharray="4,4" />
            <text x={PAD - 4} y={y + 4} fill="#64748b" fontSize="9" textAnchor="end">{v}</text>
          </g>
        );
      })}
      {/* Area fill */}
      <path d={area} fill="#0d6efd" fillOpacity="0.08" />
      {/* Line */}
      <path d={line} fill="none" stroke="#0d6efd" strokeWidth="1.5" />
      {/* Anomaly dots */}
      {anomalies.map((p, i) => (
        <circle key={i} cx={p.x} cy={p.y} r="4" fill="#ef4444" stroke="#0f172a" strokeWidth="1.5" />
      ))}
      {/* X labels */}
      {xLabels.map((p, i) => {
        const ts = p.timestamp ? String(p.timestamp).slice(5, 16) : "";
        return <text key={i} x={p.x} y={H - 4} fill="#475569" fontSize="8" textAnchor="middle">{ts}</text>;
      })}
      {/* Y axis */}
      <line x1={PAD} y1={PAD} x2={PAD} y2={H - PAD} stroke="#334155" strokeWidth="1" />
    </svg>
  );
}

// ── Meter Detail Modal ────────────────────────────────────────────────────────
function MeterModal({ meter, onClose }) {
  const [history, setHistory] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!meter) return;
    setLoading(true);
    fetch(`${API}/meter/${meter.meter_id}/history?last_n_readings=192`)
      .then(r => r.json())
      .then(d => { setHistory(d); setLoading(false); })
      .catch(() => setLoading(false));
  }, [meter]);

  if (!meter) return null;
  const anomalyReadings = history?.readings?.filter(r => r.predicted_anomaly) || [];

  return (
    <div onClick={onClose} style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.7)", zIndex: 1000, display: "flex", alignItems: "center", justifyContent: "center" }}>
      <div onClick={e => e.stopPropagation()} style={{ background: "#1e293b", borderRadius: 14, padding: 24, width: 620, maxHeight: "85vh", overflowY: "auto", border: "1px solid #334155" }}>
        {/* Header */}
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 20 }}>
          <div>
            <div style={{ fontSize: 18, fontWeight: 700, color: "#0dcaf0" }}>{meter.meter_id}</div>
            <div style={{ fontSize: 12, color: "#64748b", marginTop: 2 }}>{meter.zone} · {meter.feeder} · {meter.meter_type}</div>
          </div>
          <div style={{ textAlign: "right" }}>
            <div style={{ fontSize: 28, fontWeight: 700, color: riskColor(meter.final_risk_score) }}>{meter.final_risk_score}</div>
            <div style={{ fontSize: 10, color: "#64748b" }}>Risk Score</div>
          </div>
        </div>

        {/* Stats row */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 10, marginBottom: 20 }}>
          {[
            { label: "Loss Type", val: meter.dominant_loss_category === "non_technical" ? "Non-Technical" : meter.dominant_loss_category === "technical" ? "Technical" : "Normal", color: meter.dominant_loss_category === "non_technical" ? "#ef4444" : meter.dominant_loss_category === "technical" ? "#8b5cf6" : "#22c55e" },
            { label: "Anomalies Detected", val: meter.anomaly_count, color: "#f59e0b" },
            { label: "Anomaly Rate", val: `${(meter.anomaly_rate * 100).toFixed(1)}%`, color: "#0dcaf0" },
          ].map(s => (
            <div key={s.label} style={{ background: "#0f172a", borderRadius: 8, padding: "12px", textAlign: "center" }}>
              <div style={{ fontSize: 20, fontWeight: 700, color: s.color }}>{s.val}</div>
              <div style={{ fontSize: 10, color: "#64748b", marginTop: 2 }}>{s.label}</div>
            </div>
          ))}
        </div>

        {/* Chart */}
        <div style={{ background: "#0f172a", borderRadius: 10, padding: "14px 10px", marginBottom: 16 }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: "#0dcaf0", letterSpacing: 1, marginBottom: 10 }}>
            CONSUMPTION HISTORY — RED DOTS = ANOMALIES DETECTED BY AI
          </div>
          {loading ? (
            <div style={{ height: 180, display: "flex", alignItems: "center", justifyContent: "center", color: "#64748b", fontSize: 13 }}>Loading chart...</div>
          ) : history?.readings?.length > 0 ? (
            <SparkChart readings={history.readings} />
          ) : (
            <div style={{ height: 180, display: "flex", alignItems: "center", justifyContent: "center", color: "#64748b", fontSize: 13 }}>No data available</div>
          )}
        </div>

        {/* Recent anomalies */}
        {anomalyReadings.length > 0 && (
          <div>
            <div style={{ fontSize: 11, fontWeight: 700, color: "#ef4444", letterSpacing: 1, marginBottom: 8 }}>FLAGGED ANOMALY READINGS</div>
            <div style={{ maxHeight: 140, overflowY: "auto" }}>
              {anomalyReadings.slice(0, 8).map((r, i) => (
                <div key={i} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "6px 10px", background: "#0f172a", borderRadius: 6, marginBottom: 4, borderLeft: `3px solid ${r.predicted_loss_category === "non_technical" ? "#ef4444" : "#8b5cf6"}` }}>
                  <span style={{ fontSize: 11, color: "#94a3b8" }}>{String(r.timestamp).slice(0, 16)}</span>
                  <span style={{ fontSize: 12, fontWeight: 700, color: "#ef4444" }}>{Number(r.consumption_kwh).toFixed(3)} kWh</span>
                  <span style={{ fontSize: 10, padding: "2px 6px", borderRadius: 4, background: r.predicted_loss_category === "non_technical" ? "#ef444420" : "#8b5cf620", color: r.predicted_loss_category === "non_technical" ? "#ef4444" : "#8b5cf6" }}>
                    {r.predicted_loss_category === "non_technical" ? "Non-Technical" : "Technical"}
                  </span>
                  <span style={{ fontSize: 11, color: riskColor(r.risk_score) }}>{Number(r.risk_score).toFixed(0)}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        <button onClick={onClose} style={{ marginTop: 16, width: "100%", padding: "10px", background: "#0d6efd", border: "none", borderRadius: 8, color: "#fff", fontSize: 13, fontWeight: 600, cursor: "pointer" }}>
          Close
        </button>
      </div>
    </div>
  );
}

// ── Main App ──────────────────────────────────────────────────────────────────
export default function App() {
  const [stats, setStats] = useState(null);
  const [zones, setZones] = useState([]);
  const [meters, setMeters] = useState([]);
  const [alerts, setAlerts] = useState([]);
  const [activeTab, setActiveTab] = useState("dashboard");
  const [filterZone, setFilterZone] = useState("all");
  const [filterType, setFilterType] = useState("all");
  const [selectedMeter, setSelectedMeter] = useState(null);
  const [clock, setClock] = useState(new Date().toLocaleTimeString());

  const fetchAll = useCallback(async () => {
    try {
      const [sRes, zRes, mRes, aRes] = await Promise.all([
        fetch(`${API}/dashboard/stats`),
        fetch(`${API}/zones/summary`),
        fetch(`${API}/meters/high-risk?limit=100`),
        fetch(`${API}/alerts/recent?limit=50`),
      ]);
      if (sRes.ok) setStats(await sRes.json());
      if (zRes.ok) setZones(await zRes.json());
      if (mRes.ok) setMeters(await mRes.json());
      if (aRes.ok) setAlerts(await aRes.json());
    } catch (e) {
      console.error("API fetch failed:", e);
    }
  }, []);

  useEffect(() => {
    fetchAll();
    const dataInterval = setInterval(fetchAll, 30000);
    const clockInterval = setInterval(() => setClock(new Date().toLocaleTimeString()), 1000);
    return () => { clearInterval(dataInterval); clearInterval(clockInterval); };
  }, [fetchAll]);

  const filteredMeters = meters.filter(m => {
    if (filterZone !== "all" && m.zone !== filterZone) return false;
    if (filterType !== "all" && m.dominant_loss_category !== filterType) return false;
    return true;
  });

  const uniqueZones = [...new Set(meters.map(m => m.zone))].sort();

  // Impact calculator
  const avgLossPerMeter = 14000;
  const estimatedSavings = stats ? Math.round((stats.non_technical_losses + stats.technical_losses * 0.6) * avgLossPerMeter) : 0;

  const S = {
    app: { fontFamily: "Inter,system-ui,sans-serif", background: "#0f172a", minHeight: "100vh", color: "#e2e8f0" },
    header: { background: "#1e293b", borderBottom: "1px solid #334155", padding: "10px 20px", display: "flex", alignItems: "center", justifyContent: "space-between" },
    tab: (active) => ({ padding: "6px 14px", borderRadius: 6, border: "none", cursor: "pointer", fontSize: 12, fontWeight: 600, background: active ? "#0d6efd" : "transparent", color: active ? "#fff" : "#94a3b8" }),
    card: (border) => ({ background: "#1e293b", borderRadius: 12, padding: "14px", flex: 1, border: `1px solid ${border || "#1e293b"}` }),
    section: { background: "#1e293b", borderRadius: 12, padding: 18 },
    label: { fontSize: 11, fontWeight: 700, color: "#0dcaf0", letterSpacing: 1, marginBottom: 14 },
  };

  return (
    <div style={S.app}>
      {/* Header */}
      <div style={S.header}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <div style={{ width: 32, height: 32, background: "linear-gradient(135deg,#0d6efd,#0dcaf0)", borderRadius: 8, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16 }}>⚡</div>
          <div>
            <div style={{ fontWeight: 700, fontSize: 15, color: "#fff" }}>GridGuard</div>
            <div style={{ fontSize: 10, color: "#64748b" }}>AI Smart Meter Intelligence · BESCOM</div>
          </div>
        </div>
        <div style={{ display: "flex", gap: 6 }}>
          {["dashboard", "meters", "alerts"].map(tab => (
            <button key={tab} style={S.tab(activeTab === tab)} onClick={() => setActiveTab(tab)}>{tab.charAt(0).toUpperCase() + tab.slice(1)}</button>
          ))}
        </div>
        <div style={{ fontSize: 11, color: "#22c55e", display: "flex", alignItems: "center", gap: 6 }}>
          <span style={{ width: 8, height: 8, borderRadius: "50%", background: "#22c55e", display: "inline-block", animation: "pulse 2s infinite" }} />
          Live · {clock}
        </div>
      </div>

      <div style={{ padding: 18 }}>

        {/* ── DASHBOARD ── */}
        {activeTab === "dashboard" && (
          <div>
            {/* Stat cards */}
            <div style={{ display: "flex", gap: 12, marginBottom: 18, flexWrap: "wrap" }}>
              {[
                { label: "Total Meters", val: stats?.total_meters ?? "—", color: "#0dcaf0", icon: "📡" },
                { label: "Anomalous", val: stats?.anomalous_meters ?? "—", color: "#f59e0b", icon: "⚠️" },
                { label: "High Risk", val: stats?.high_risk_meters ?? "—", color: "#ef4444", icon: "🚨" },
                { label: "Technical Loss", val: stats?.technical_losses ?? "—", color: "#8b5cf6", icon: "⚡" },
                { label: "Non-Technical", val: stats?.non_technical_losses ?? "—", color: "#ec4899", icon: "🔓" },
                { label: "Avg Risk Score", val: stats ? stats.avg_risk_score.toFixed(1) : "—", color: "#22c55e", icon: "📊" },
              ].map(st => (
                <div key={st.label} style={S.card(`${st.color}30`)}>
                  <div style={{ fontSize: 18, marginBottom: 2 }}>{st.icon}</div>
                  <div style={{ fontSize: 24, fontWeight: 700, color: st.color }}>{st.val}</div>
                  <div style={{ fontSize: 10, color: "#64748b", marginTop: 2 }}>{st.label}</div>
                </div>
              ))}
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginBottom: 16 }}>
              {/* Zone heatmap */}
              <div style={S.section}>
                <div style={S.label}>ZONE RISK HEATMAP</div>
                {zones.map(z => (
                  <div key={z.zone} style={{ display: "flex", alignItems: "center", gap: 10, background: "#0f172a", borderRadius: 8, padding: "9px 12px", marginBottom: 7, border: `1px solid ${riskColor(z.avg_risk_score)}30` }}>
                    <div style={{ minWidth: 58, fontSize: 12, fontWeight: 600, color: "#94a3b8" }}>{z.zone}</div>
                    <div style={{ flex: 1, height: 7, background: "#1e293b", borderRadius: 4, overflow: "hidden" }}>
                      <div style={{ height: "100%", width: `${z.avg_risk_score}%`, background: riskColor(z.avg_risk_score), borderRadius: 4 }} />
                    </div>
                    <div style={{ minWidth: 36, fontSize: 13, fontWeight: 700, color: riskColor(z.avg_risk_score), textAlign: "right" }}>{z.avg_risk_score.toFixed(1)}</div>
                    <div style={{ fontSize: 10, padding: "2px 6px", borderRadius: 4, background: `${riskColor(z.avg_risk_score)}20`, color: riskColor(z.avg_risk_score), fontWeight: 700, minWidth: 52, textAlign: "center" }}>{riskLabel(z.avg_risk_score)}</div>
                    <div style={{ fontSize: 10, color: "#64748b", minWidth: 80 }}>🔴{z.non_technical_losses} 🔵{z.technical_losses}</div>
                  </div>
                ))}
              </div>

              {/* Right column: alerts + impact */}
              <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
                {/* Live alerts from API */}
                <div style={{ ...S.section, flex: 1 }}>
                  <div style={{ fontSize: 11, fontWeight: 700, color: "#ef4444", letterSpacing: 1, marginBottom: 10 }}>🔴 LIVE ANOMALY ALERTS (FROM AI MODEL)</div>
                  <div style={{ maxHeight: 230, overflowY: "auto" }}>
                    {alerts.length === 0 ? (
                      <div style={{ color: "#64748b", fontSize: 12, padding: 12, textAlign: "center" }}>Loading alerts...</div>
                    ) : alerts.slice(0, 8).map((a, i) => (
                      <div key={i} style={{ background: "#0f172a", borderRadius: 8, padding: "8px 10px", marginBottom: 5, borderLeft: `3px solid ${a.predicted_loss_category === "non_technical" ? "#ef4444" : "#8b5cf6"}` }}>
                        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                          <span style={{ fontSize: 11, fontWeight: 700, color: "#e2e8f0" }}>{a.meter_id}</span>
                          <span style={{ fontSize: 11, fontWeight: 700, color: riskColor(a.risk_score) }}>Risk: {Math.round(a.risk_score)}</span>
                        </div>
                        <div style={{ display: "flex", gap: 6, marginTop: 3, alignItems: "center" }}>
                          <span style={{ fontSize: 10, color: "#64748b" }}>{a.zone} · {a.feeder}</span>
                          <span style={{ fontSize: 9, padding: "1px 5px", borderRadius: 3, background: a.predicted_loss_category === "non_technical" ? "#ef444420" : "#8b5cf620", color: a.predicted_loss_category === "non_technical" ? "#ef4444" : "#8b5cf6" }}>
                            {a.predicted_loss_category === "non_technical" ? "Non-Technical" : "Technical"}
                          </span>
                          <span style={{ fontSize: 9, color: "#475569", marginLeft: "auto" }}>{String(a.timestamp).slice(11, 16)}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Impact calculator */}
                <div style={{ background: "#0f172a", borderRadius: 12, padding: 16, border: "1px solid #22c55e30" }}>
                  <div style={{ fontSize: 11, fontWeight: 700, color: "#22c55e", letterSpacing: 1, marginBottom: 12 }}>💰 ESTIMATED IMPACT CALCULATOR</div>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
                    {[
                      { label: "Flagged Meters", val: stats ? stats.technical_losses + stats.non_technical_losses : "—", color: "#f59e0b" },
                      { label: "Potential Savings", val: stats ? `₹${(estimatedSavings / 100000).toFixed(1)}L` : "—", color: "#22c55e" },
                      { label: "High Risk Meters", val: stats?.high_risk_meters ?? "—", color: "#ef4444" },
                      { label: "Detection Accuracy", val: "92%+", color: "#0dcaf0" },
                    ].map(s => (
                      <div key={s.label} style={{ background: "#1e293b", borderRadius: 8, padding: "10px", textAlign: "center" }}>
                        <div style={{ fontSize: 18, fontWeight: 700, color: s.color }}>{s.val}</div>
                        <div style={{ fontSize: 10, color: "#64748b", marginTop: 2 }}>{s.label}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ── METERS ── */}
        {activeTab === "meters" && (
          <div>
            <div style={{ display: "flex", gap: 10, marginBottom: 14, alignItems: "center" }}>
              <select value={filterZone} onChange={e => setFilterZone(e.target.value)} style={{ background: "#1e293b", color: "#e2e8f0", border: "1px solid #334155", borderRadius: 8, padding: "7px 12px", fontSize: 12 }}>
                <option value="all">All Zones</option>
                {uniqueZones.map(z => <option key={z} value={z}>{z}</option>)}
              </select>
              <select value={filterType} onChange={e => setFilterType(e.target.value)} style={{ background: "#1e293b", color: "#e2e8f0", border: "1px solid #334155", borderRadius: 8, padding: "7px 12px", fontSize: 12 }}>
                <option value="all">All Loss Types</option>
                <option value="non_technical">Non-Technical</option>
                <option value="technical">Technical</option>
                <option value="normal">Normal</option>
              </select>
              <span style={{ marginLeft: "auto", fontSize: 12, color: "#64748b" }}>{filteredMeters.length} meters · click any row to see consumption chart</span>
            </div>
            <div style={{ background: "#1e293b", borderRadius: 12, overflow: "hidden" }}>
              <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 12 }}>
                <thead>
                  <tr style={{ background: "#0f172a" }}>
                    {["Meter ID", "Zone", "Feeder", "Type", "Risk Score", "Loss Category", "Anomalies", "Rate"].map(h => (
                      <th key={h} style={{ padding: "10px 14px", textAlign: "left", color: "#64748b", fontSize: 10, letterSpacing: 1 }}>{h.toUpperCase()}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {filteredMeters.map((m) => (
                    <tr key={m.meter_id} onClick={() => setSelectedMeter(m)}
                      style={{ borderTop: "1px solid #1e293b", cursor: "pointer", background: "transparent", transition: "background 0.1s" }}
                      onMouseEnter={e => e.currentTarget.style.background = "#0d6efd15"}
                      onMouseLeave={e => e.currentTarget.style.background = "transparent"}>
                      <td style={{ padding: "10px 14px", color: "#0dcaf0", fontWeight: 600 }}>{m.meter_id}</td>
                      <td style={{ padding: "10px 14px", color: "#94a3b8" }}>{m.zone}</td>
                      <td style={{ padding: "10px 14px", color: "#94a3b8" }}>{m.feeder}</td>
                      <td style={{ padding: "10px 14px" }}>
                        <span style={{ fontSize: 10, padding: "2px 7px", borderRadius: 4, background: "#0f172a", color: "#94a3b8", border: "1px solid #334155" }}>{m.meter_type}</span>
                      </td>
                      <td style={{ padding: "10px 14px" }}>
                        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                          <div style={{ width: 44, height: 5, background: "#0f172a", borderRadius: 3, overflow: "hidden" }}>
                            <div style={{ height: "100%", width: `${m.final_risk_score}%`, background: riskColor(m.final_risk_score), borderRadius: 3 }} />
                          </div>
                          <span style={{ color: riskColor(m.final_risk_score), fontWeight: 700 }}>{m.final_risk_score}</span>
                        </div>
                      </td>
                      <td style={{ padding: "10px 14px" }}>
                        <span style={{ fontSize: 10, padding: "2px 7px", borderRadius: 4, fontWeight: 700,
                          background: m.dominant_loss_category === "non_technical" ? "#ef444420" : m.dominant_loss_category === "technical" ? "#8b5cf620" : "#22c55e20",
                          color: m.dominant_loss_category === "non_technical" ? "#ef4444" : m.dominant_loss_category === "technical" ? "#8b5cf6" : "#22c55e" }}>
                          {m.dominant_loss_category === "non_technical" ? "Non-Technical" : m.dominant_loss_category === "technical" ? "Technical" : "Normal"}
                        </span>
                      </td>
                      <td style={{ padding: "10px 14px", color: "#e2e8f0" }}>{m.anomaly_count}</td>
                      <td style={{ padding: "10px 14px", color: "#94a3b8" }}>{(m.anomaly_rate * 100).toFixed(1)}%</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* ── ALERTS ── */}
        {activeTab === "alerts" && (
          <div>
            <div style={{ fontSize: 11, fontWeight: 700, color: "#0dcaf0", letterSpacing: 1, marginBottom: 14 }}>REAL-TIME ANOMALY FEED — FROM AI MODEL (predictions.csv)</div>
            {alerts.length === 0 ? (
              <div style={{ color: "#64748b", fontSize: 13, padding: 20, textAlign: "center" }}>No alerts loaded. Make sure the API is running.</div>
            ) : alerts.map((a, i) => (
              <div key={i} style={{ background: "#1e293b", borderRadius: 10, padding: "12px 16px", borderLeft: `4px solid ${riskColor(a.risk_score)}`, display: "flex", alignItems: "center", gap: 16, marginBottom: 8 }}>
                <div style={{ fontSize: 20 }}>{a.predicted_loss_category === "non_technical" ? "🔓" : "⚡"}</div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 13, fontWeight: 700, color: "#fff" }}>{a.meter_id} — {a.zone} · {a.feeder}</div>
                  <div style={{ fontSize: 11, color: "#64748b", marginTop: 2 }}>
                    {a.predicted_loss_category === "non_technical" ? "Non-Technical Loss — possible tampering or unauthorized connection" : "Technical Loss — line fault or transformer irregularity"}
                  </div>
                  <div style={{ fontSize: 10, color: "#475569", marginTop: 3 }}>Consumption: {Number(a.consumption_kwh).toFixed(4)} kWh · {String(a.timestamp).slice(0, 19)}</div>
                </div>
                <div style={{ textAlign: "right" }}>
                  <div style={{ fontSize: 22, fontWeight: 700, color: riskColor(a.risk_score) }}>{Math.round(a.risk_score)}</div>
                  <div style={{ fontSize: 10, color: "#64748b" }}>Risk Score</div>
                </div>
                <button style={{ fontSize: 11, padding: "5px 12px", borderRadius: 6, border: "1px solid #0d6efd", background: "transparent", color: "#0d6efd", cursor: "pointer" }}
                  onClick={() => alert(`Field inspection assigned for ${a.meter_id}`)}>
                  Assign
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Meter detail modal */}
      <MeterModal meter={selectedMeter} onClose={() => setSelectedMeter(null)} />

      <style>{`
        @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:.3} }
        *{box-sizing:border-box}
        ::-webkit-scrollbar{width:5px} ::-webkit-scrollbar-track{background:#0f172a} ::-webkit-scrollbar-thumb{background:#334155;border-radius:3px}
      `}</style>
    </div>
  );
}
