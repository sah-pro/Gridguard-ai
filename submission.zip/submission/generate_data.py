"""
GridGuard - Synthetic Smart Meter Data Generator
Generates realistic BESCOM-pattern consumption data with injected anomalies
"""
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
import random

np.random.seed(42)
random.seed(42)

NUM_METERS = 500
DAYS = 30
INTERVAL_MINUTES = 15
READINGS_PER_DAY = 96  # 24*60/15


def generate_normal_consumption(meter_type="residential"):
    """Generate realistic daily consumption pattern"""
    hours = np.arange(0, 24, 0.25)  # 15-min intervals

    if meter_type == "residential":
        # Morning peak (7-9am), Evening peak (6-10pm)
        base = 0.15 + 0.1 * np.sin(2 * np.pi * (hours - 8) / 24)
        morning_peak = 0.4 * np.exp(-0.5 * ((hours - 7.5) / 1.5) ** 2)
        evening_peak = 0.6 * np.exp(-0.5 * ((hours - 20) / 2.0) ** 2)
        pattern = base + morning_peak + evening_peak
    elif meter_type == "commercial":
        # Business hours 9am-6pm
        pattern = np.where((hours >= 9) & (hours <= 18), 1.2, 0.1)
        pattern = pattern + 0.05 * np.random.randn(len(hours))
    else:  # industrial
        pattern = 0.8 + 0.2 * np.sin(2 * np.pi * hours / 12)

    return np.clip(pattern, 0.01, None)


def inject_anomaly(readings, anomaly_type):
    """Inject specific anomaly patterns into meter readings"""
    n = len(readings)
    anomaly_start = random.randint(n // 4, 3 * n // 4)
    anomaly_len = random.randint(4, 20)
    end = min(anomaly_start + anomaly_len, n)

    if anomaly_type == "sudden_drop":
        # Meter bypass / tampering — consumption drops to near zero
        readings[anomaly_start:end] = readings[anomaly_start:end] * 0.05
        label = "non_technical"

    elif anomaly_type == "sudden_spike":
        # Unauthorized connection — sudden surge
        readings[anomaly_start:end] = readings[anomaly_start:end] * random.uniform(3, 6)
        label = "non_technical"

    elif anomaly_type == "flatline":
        # Meter stuck / tampered — constant reading
        flat_val = np.mean(readings) * 0.3
        readings[anomaly_start:end] = flat_val
        label = "non_technical"

    elif anomaly_type == "gradual_increase":
        # Illegal load addition
        for i in range(anomaly_start, end):
            readings[i] *= 1 + 0.05 * (i - anomaly_start)
        label = "non_technical"

    elif anomaly_type == "intermittent_zero":
        # Line fault — readings drop to zero intermittently
        for i in range(anomaly_start, end, 2):
            readings[i] = 0
        label = "technical"

    elif anomaly_type == "high_variance":
        # Transformer issue — unstable supply
        readings[anomaly_start:end] *= np.random.uniform(0.2, 2.5, end - anomaly_start)
        label = "technical"

    return readings, label, anomaly_start


def generate_dataset():
    records = []
    anomaly_types = [
        "sudden_drop", "sudden_spike", "flatline",
        "gradual_increase", "intermittent_zero", "high_variance"
    ]
    meter_types = ["residential"] * 350 + ["commercial"] * 100 + ["industrial"] * 50

    # 15% of meters have anomalies
    anomaly_meter_ids = set(random.sample(range(NUM_METERS), int(NUM_METERS * 0.15)))

    start_date = datetime(2025, 3, 1)
    timestamps = [
        start_date + timedelta(minutes=15 * i)
        for i in range(DAYS * READINGS_PER_DAY)
    ]

    print(f"Generating data for {NUM_METERS} meters over {DAYS} days...")

    for meter_id in range(NUM_METERS):
        meter_type = meter_types[meter_id]
        zone = f"Zone_{chr(65 + meter_id % 8)}"  # Zone_A to Zone_H
        feeder = f"Feeder_{(meter_id // 8) % 10 + 1}"

        # Generate base consumption pattern
        daily_pattern = generate_normal_consumption(meter_type)
        all_readings = np.tile(daily_pattern, DAYS).copy()

        # Add realistic noise
        noise = np.random.normal(0, 0.02, len(all_readings))
        all_readings = np.clip(all_readings + noise, 0, None)

        # Inject anomaly if this meter is selected
        is_anomaly = meter_id in anomaly_meter_ids
        anomaly_label = "normal"
        anomaly_start_idx = -1

        if is_anomaly:
            anomaly_type = random.choice(anomaly_types)
            all_readings, anomaly_label, anomaly_start_idx = inject_anomaly(
                all_readings.copy(), anomaly_type
            )
        else:
            anomaly_type = "none"

        for i, (ts, reading) in enumerate(zip(timestamps, all_readings)):
            records.append({
                "meter_id": f"METER_{meter_id:04d}",
                "consumer_id": f"BESCOM_{random.randint(100000, 999999)}",
                "timestamp": ts,
                "consumption_kwh": round(reading, 4),
                "zone": zone,
                "feeder": feeder,
                "meter_type": meter_type,
                "is_anomaly": is_anomaly and (i >= anomaly_start_idx),
                "anomaly_type": anomaly_type if is_anomaly else "none",
                "loss_category": anomaly_label if is_anomaly else "normal",
            })

    df = pd.DataFrame(records)
    df.to_csv("meter_data.csv", index=False)
    print(f"✅ Generated {len(df)} records")
    print(f"   Anomalous meters: {len(anomaly_meter_ids)}")
    print(f"   Saved to meter_data.csv")
    return df


if __name__ == "__main__":
    df = generate_dataset()
    print("\nSample anomaly distribution:")
    print(df[df["is_anomaly"]]["anomaly_type"].value_counts())
